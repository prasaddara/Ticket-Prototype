# Frontend - Ticket Management module (React + Vite)
## Quick start
1. cd frontend
2. npm install
3. npm run dev
4. Open http://localhost:5173
## Notes
- The frontend talks to backend at http://localhost:4000/api by default. Use VITE_API_URL env to change.
